export MYSQL_HOST=localhost
export MYSQL_DATABASE=Market_Simulator
export MYSQL_USER=user
export MYSQL_PASSWORD=user-pass
