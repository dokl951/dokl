package com.fms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarketSimulatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(MarketSimulatorApplication.class, args);
    }
}
