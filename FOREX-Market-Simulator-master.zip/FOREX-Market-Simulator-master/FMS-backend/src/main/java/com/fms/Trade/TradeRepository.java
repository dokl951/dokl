package com.fms.Trade;


import org.springframework.data.repository.CrudRepository;


public interface TradeRepository extends CrudRepository<Trade, Integer> {


}
