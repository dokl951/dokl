﻿export class User {

  id: number;
  createdOn: Date;
  username: string;
  password: string;
  firstName: string;
  lastName: string;
  email: string;
  wallet: any;
}
