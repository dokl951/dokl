export class Wallet {
  id: number;
  balance: number;
  equity: number;
  freeMargin: number;
  margin: number;
  profit: number;
}
