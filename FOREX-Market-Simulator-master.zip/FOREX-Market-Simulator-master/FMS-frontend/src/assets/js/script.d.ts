export declare function TradingViewwidget();
